package com.payment.dto;


import lombok.Getter;

@Getter
public class LoanRequestObj {

   String loanAmount;
   String nominalRate;
    String duration;
   String startDate;

}
